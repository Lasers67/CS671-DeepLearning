import numpy as np
import os
import cv2
from PIL import Image
from sklearn.model_selection import train_test_split
split = 0.75
x=[]
y=[]
path_data="/media/lasers67/New Volume1/Assignment3/Q3/Core_Point/Data/"
path_label="/media/lasers67/New Volume1/Assignment3/Q3/Core_Point/Ground_truth/"
temp_x=[]
temp_y=[]

for i in os.listdir(path_data):
	temp_x.append(i)
for i in os.listdir(path_label):
	temp_y.append(i)
temp_x=sorted(temp_x)
temp_y=sorted(temp_y)
for i in range(len(temp_x)):
	img=Image.open(path_data+temp_x[i])
	if np.shape(np.asarray(img))!=(480, 320):
		img=cv2.imread(path_data+temp_x[i],0)
		img=cv2.resize(img, dsize=(320, 480), interpolation=cv2.INTER_CUBIC)
	x.append(np.asarray(img))
	f=open(path_label+temp_y[i])
	a=f.read()
	y.append(np.asarray([int(a.split(" ")[0]),int(a.split(" ")[1])]))
train_x=np.asarray(x[:int(len(x) * .75)])
test_x=np.asarray(x[(int(len(x) * .75)):])
train_y=np.asarray(y[:int(len(y) * .75)])
test_y=np.asarray(y[(int(len(y) * .75)):])
np.save("train_x.npy",train_x)
np.save("train_y.npy",train_y)
np.save("test_x.npy",test_x)
np.save("test_y.npy",test_y)