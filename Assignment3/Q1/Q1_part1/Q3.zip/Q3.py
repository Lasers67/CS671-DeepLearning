import argparse
parser = argparse.ArgumentParser()
parser.add_argument("-p", "--phase", help="Train or test phase")
parser.add_argument("-e", "--epochs", help="epochs")
args = parser.parse_args()	
print (args)
import numpy as np
from keras.layers import Conv2D, MaxPooling2D, Input, Dense, Flatten, Activation, BatchNormalization,Dropout
from keras.models import Model
from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf
import matplotlib.pyplot as plt
from keras import backend as K
from sklearn.metrics import confusion_matrix
if args.phase=="train":
	batch_size=100
	n_filters_conv1=16
	n_filters_conv2=32
	n_filters_conv3=64
	n_filters_conv4=80
	#path = "drive/My Drive/Convo/"
	path=""
	inp=np.load(path+"train_x.npy")
	y=np.load(path+"train_y.npy")
	x_test,y_test=np.load(path+"test_x.npy"),np.load(path+"test_y.npy")
	inp, x_test = inp / 255.0, x_test / 255.0
	inp, x_test = np.reshape(inp, inp.shape + (1,)), np.reshape(x_test, x_test.shape + (1,)) 
	input_layer=Input(shape=(480, 320,1))
	conv1=Conv2D(n_filters_conv1, kernel_size=(32,32), strides=1,padding="same",activation="relu")(input_layer)
	batch = BatchNormalization(axis=2)(conv1)
	pool1 = MaxPooling2D(pool_size=(11,11), strides=2)(batch)
	conv2 = Conv2D(n_filters_conv2, kernel_size=(13,13), strides=1,activation="relu")(pool1)
	pool2 = MaxPooling2D(pool_size=(7,7), strides=2)(conv2)
	conv3 = Conv2D(n_filters_conv3, kernel_size=(9,9), strides=1,activation="relu")(pool2)
	pool3 = MaxPooling2D(pool_size=(3,3), strides=2)(conv3)
	conv4 = Conv2D(n_filters_conv4, kernel_size=(3,3), strides=1,activation="relu")(pool3)
	pool4 = MaxPooling2D(pool_size=(2,2), strides=2)(conv4)
	flat = Flatten()(pool4)
	dense1= Dense(64,activation="relu")(flat)
	dropout=Dropout(0.2)(dense1)
	dense2=Dense(32,activation="relu")(dropout)
	logits=Dense(2)(dense2)
	model = Model(inputs=input_layer, outputs=logits)
	model.compile(loss='mean_squared_error',optimizer='adam',metrics=['accuracy'])
	history = model.fit(inp, y, epochs=args.epochs, batch_size=128, shuffle=True)
	model.save('model.h5')
elif args.phase=="test":
	print("Enter the testing images folder:")
	path=input()
	if path[-1]!='/':
		path+='/'
	from keras.models import load_model
	model=load_model('model.h5')
	print(model.summary())
	import os
	from PIL import Image
	# import cv2
	test=[]
	files=[]
	for i in os.listdir(path):
		files.append(i)
		img=Image.open(path+i)
		# print(img)
		# if np.shape(np.asarray(img))!=(480, 320):
		# 	img=cv2.imread(path_data+temp_x[i],0)
		# 	img=cv2.resize(img, dsize=(320, 480), interpolation=cv2.INTER_CUBIC)
		test.append((np.asarray(img).reshape((480, 320, 1))))
	test=np.asarray(test)
	test=test/255.
	ynew=model.predict(test)
	for i in range(len(ynew)):
		# print (ynew[i])
		file = open("res/"+ files[i].split('.')[0] + ".txt", "w") 
		file.write(str(ynew[i][0]) + " " + str(ynew[i][1])) 
		file.close() 